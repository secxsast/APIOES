#!/bin/sh
export TRANSIENT_DB=true
export USER_SALT=qzdveigybpisfxsvyzqefquouuiwvmsr
python main.py